public class Main {
    public static void main(String[] args) {
        bankAccount momAccount = new bankAccount();

        momAccount.setAccountNumber(48965414);
        momAccount.setAccountBalance(10000.00);
        momAccount.setCustomerName("S A N Pathiraja");
        momAccount.setEmail("sanpathi714@gmail.com");
        momAccount.setPhoneNumber("(94)715036461");

        momAccount.withdrawFunds(100.00);
        
        momAccount.depositFunds(250.00);

        momAccount.withdrawFunds(50);
        momAccount.withdrawFunds(200);

        momAccount.depositFunds(100);

        momAccount.withdrawFunds(45.55);
        momAccount.withdrawFunds(55.54);

    }
}