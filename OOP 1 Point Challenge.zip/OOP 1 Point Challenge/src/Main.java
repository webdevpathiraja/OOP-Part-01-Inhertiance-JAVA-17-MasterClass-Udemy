public class Main {
    public static void main(String[] args) {
        Point point = new Point(3,2);
        System.out.println("distance = " + point.distance());
    }
}