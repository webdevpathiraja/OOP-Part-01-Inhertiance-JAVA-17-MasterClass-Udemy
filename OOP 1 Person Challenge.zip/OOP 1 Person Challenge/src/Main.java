
public class Main {
    public static void main(String[] args) {
        Person person1 = new Person();

        person1.setFirstName("");   // firstName is set to empty string
        person1.setLastName("");    // lastName is set to empty string
        person1.setAge(10);
        System.out.println("fullName = " + person1.getFullName());
        System.out.println("teen = " + person1.isTeen());
        System.out.println();

        Person person2 = new Person();

        person2.setFirstName("Anupama");
        person2.setLastName("Ushetti");
        person2.setAge(57);
        System.out.println("fullName = " + person2.getFullName());
        System.out.println("teen = " + person2.isTeen());
        System.out.println();

        Person person3 = new Person();

        person3.setFirstName("");
        person3.setLastName("Pathiraja");
        person3.setAge(18);
        System.out.println("fullName = " + person3.getFullName());
        System.out.println("teen = " + person3.isTeen());
    }
}


